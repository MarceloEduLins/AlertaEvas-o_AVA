const path = require('path');
const { execFile } = require('child_process');
const { buildFeatureRows } = require('./academic.service');

function runPython(input) {
  return new Promise((resolve, reject) => {
    const script = path.join(__dirname, '..', '..', 'scripts', 'cluster_students.py');
    const candidates = process.platform === 'win32' ? ['python', 'py'] : ['python3', 'python'];

    function attempt(index) {
      if (index >= candidates.length) {
        reject(new Error('Python não encontrado. Instale Python 3 para executar o módulo de clustering.'));
        return;
      }
      const child = execFile(candidates[index], [script], { maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
        if (error) {
          if (error.code === 'ENOENT') return attempt(index + 1);
          return reject(new Error(stderr || error.message));
        }
        try {
          resolve(JSON.parse(stdout));
        } catch (parseError) {
          reject(new Error(`Resposta inválida do módulo Python: ${parseError.message}`));
        }
      });
      child.stdin.write(JSON.stringify(input));
      child.stdin.end();
    }

    attempt(0);
  });
}

async function clusterClass(classId) {
  const rows = buildFeatureRows(classId);
  const result = await runPython(rows);
  return { ...result, rows };
}

module.exports = { clusterClass };

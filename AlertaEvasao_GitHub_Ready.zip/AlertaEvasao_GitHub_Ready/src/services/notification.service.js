function firstName(student){ return student.name.split(' ')[0]; }

function buildAttendanceNotification(student, subjectAnalysis) {
  const { subject, attendance } = subjectAnalysis;
  const remaining = attendance.remainingAbsences;
  if (!['reminder', 'attention', 'critical'].includes(attendance.alertLevel)) return null;
  const remainingText = remaining > 1 ? `${remaining} faltas` : remaining === 1 ? '1 falta' : 'nenhuma falta adicional';

  if (attendance.alertLevel === 'reminder') return {
    type:'attendance',level:'reminder',reference:`remaining:${remaining}`,
    subject:`Sua frequência em ${subject.name}`,
    body:`Olá, ${firstName(student)}! Você ainda pode ter aproximadamente ${remainingText} em ${subject.name} antes de atingir o limite configurado. Sua frequência atual é ${attendance.currentAttendance}%. É só um lembrete para ajudar no acompanhamento do semestre.`
  };
  if (attendance.alertLevel === 'attention') return {
    type:'attendance',level:'attention',reference:`band:attention`,
    subject:`Atenção à frequência em ${subject.name}`,
    body:`Olá, ${firstName(student)}. Sua margem em ${subject.name} ficou pequena: restam aproximadamente ${remainingText}. Frequência atual: ${attendance.currentAttendance}%. Vale acompanhar as próximas aulas com atenção.`
  };
  return {
    type:'attendance',level:'critical',reference:'band:critical',
    subject:`Alerta importante de frequência em ${subject.name}`,
    body:`Olá, ${firstName(student)}. Sua frequência em ${subject.name} chegou a um nível crítico. Frequência atual: ${attendance.currentAttendance}%. Margem estimada: ${remainingText}. Se estiver enfrentando alguma dificuldade, procure o professor ou o apoio acadêmico.`
  };
}

function buildAvaNotification(student, subjectAnalysis) {
  const { subject, ava }=subjectAnalysis;
  if (!['attention','critical'].includes(ava.alertLevel)) return null;
  if (ava.alertLevel==='attention') return {
    type:'ava',level:'attention',reference:'band:8d',subject:'Lembrete sobre seu acesso ao AVA',
    body:`Olá, ${firstName(student)}! Faz ${ava.inactiveDays} dias que você não acessa o AVA. Em ${subject.name}, há ${ava.pendingActivities} atividade(s) pendente(s). Vale dar uma olhada para não acumular conteúdo.`
  };
  return {
    type:'ava',level:'critical',reference:'band:15d',subject:'Atenção importante ao seu acesso no AVA',
    body:`Olá, ${firstName(student)}. Identificamos ${ava.inactiveDays} dias sem acesso ao AVA. Em ${subject.name}, existem ${ava.pendingActivities} atividade(s) pendente(s). Recomendamos verificar o ambiente virtual e, se necessário, procurar apoio acadêmico.`
  };
}

function buildGradeNotification(student, subjectAnalysis) {
  const assessment=subjectAnalysis.assessments?.[0];
  if (!assessment || assessment.grade===null || assessment.grade>=7) return null;
  const weakest=assessment.weakest;
  const critical=assessment.grade<5;
  return {
    type:'grade',level:critical?'critical':'attention',reference:`${assessment.name}:${assessment.releaseDate||''}`,
    subject:`Resultado de ${assessment.name} em ${subjectAnalysis.subject.name}`,
    body:`Olá, ${firstName(student)}. Sua média em ${assessment.name} de ${subjectAnalysis.subject.name} foi ${assessment.grade.toFixed(1)}. O componente que mais reduziu o resultado foi ${weakest?.type || 'a avaliação'} (${weakest?.grade?.toFixed?.(1) ?? weakest?.grade}). Este aviso serve para ajudar você a identificar cedo onde concentrar sua recuperação.`
  };
}

module.exports={buildAttendanceNotification,buildAvaNotification,buildGradeNotification};

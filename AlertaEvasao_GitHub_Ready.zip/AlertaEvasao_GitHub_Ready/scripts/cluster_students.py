import json
import sys
from collections import Counter

import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

FEATURES = [
    "avgAttendance",
    "avgGrade",
    "avgInactiveDays",
    "pendingActivities",
    "avgExamGrade",
    "avgProjectGrade",
]


def profile_name(center):
    attendance, grade, inactive, pending, exam, project = center

    issues = []
    if attendance < 80:
        issues.append((100 - attendance, "Risco por frequência"))
    if inactive >= 8 or pending >= 5:
        issues.append((inactive + pending * 1.5, "Desengajamento no AVA"))
    if exam < 6.5 and exam + 0.6 < project:
        issues.append(((7 - exam) * 5, "Dificuldade em provas"))
    if project < 6.5 and project + 0.6 < exam:
        issues.append(((7 - project) * 5, "Dificuldade em projetos"))
    if grade < 6 and abs(exam - project) <= 0.6:
        issues.append(((7 - grade) * 5, "Dificuldade acadêmica geral"))

    if not issues:
        return "Perfil estável"
    return max(issues, key=lambda item: item[0])[1]


def main():
    rows = json.load(sys.stdin)
    if not rows:
        print(json.dumps({"clusters": [], "model": {"algorithm": "K-Means", "k": 0}}))
        return

    k = min(5, len(rows))
    matrix = np.array([[float(row.get(feature, 0) or 0) for feature in FEATURES] for row in rows], dtype=float)
    scaler = StandardScaler()
    scaled = scaler.fit_transform(matrix)

    model = KMeans(n_clusters=k, random_state=42, n_init=20)
    labels = model.fit_predict(scaled)
    centers_raw = scaler.inverse_transform(model.cluster_centers_)

    clusters = []
    used_names = Counter()
    for cluster_id in range(k):
        members = [rows[i] for i, label in enumerate(labels) if int(label) == cluster_id]
        center = centers_raw[cluster_id]
        base_name = profile_name(center)
        used_names[base_name] += 1
        name = base_name if used_names[base_name] == 1 else f"{base_name} {used_names[base_name]}"
        clusters.append({
            "id": int(cluster_id),
            "name": name,
            "size": len(members),
            "members": [{"studentId": m["studentId"], "name": m["name"]} for m in members],
            "center": {feature: round(float(center[i]), 2) for i, feature in enumerate(FEATURES)}
        })

    result = {
        "model": {
            "algorithm": "K-Means",
            "k": k,
            "features": FEATURES,
            "note": "Agrupamento exploratório não supervisionado. Os nomes dos perfis são interpretações dos centróides, não rótulos treinados."
        },
        "clusters": sorted(clusters, key=lambda c: c["size"], reverse=True)
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

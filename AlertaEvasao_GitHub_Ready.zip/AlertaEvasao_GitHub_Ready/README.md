# Alerta Evasão V3 — Simulação de semestre

Protótipo acadêmico de **monitoramento preventivo de risco acadêmico**. A V3 foi criada para deixar a proatividade visível: o calendário do semestre avança, aulas acontecem, faltas são acumuladas, RAs chegam em datas diferentes, notas são liberadas, o tempo sem acesso ao AVA aumenta e o sistema reage automaticamente.

> Os estudantes, notas, faltas, acessos e eventos usados na demonstração são fictícios/sintéticos. O projeto não afirma prever evasão com certeza; ele identifica sinais que justificam acompanhamento humano.

## Cenário da turma

- Curso demonstrativo: Ciência da Computação — 1º período
- Semestre: 2026/1
- 24 alunos fictícios
- 6 disciplinas
- 5 aulas por dia, de segunda a sexta
- Presença mínima configurada: 75%
- RAs com quantidades e datas diferentes conforme a disciplina

### Disciplinas do cenário

As seis disciplinas usadas correspondem às disciplinas de 1º período listadas na matriz curricular pública de Ciência da Computação da PUCPR:

1. Raciocínio Algorítmico
2. Experiência Criativa: Navegando na Computação
3. Filosofia
4. Descoberta e Evolução da Computação
5. Modelagem de Fenômenos Físicos
6. Leitura e Escrita Acadêmica

A página pública do curso também disponibiliza uma matriz vigente para ingressantes 2026/1. Como matrizes podem ser atualizadas pela instituição, a versão final institucional deve sempre ser conferida na página oficial do curso.

## O que está implementado

### Simulação temporal

A tela **Simulação do semestre** possui três ações:

- `Avançar 1 semana`
- `Ir ao próximo evento`
- `Reiniciar semestre`

Ao avançar o tempo, o backend atualiza automaticamente:

- aulas realizadas;
- faltas de cada aluno por disciplina;
- frequência acumulada;
- quantidade de faltas ainda disponível até o limite;
- último acesso ao AVA;
- atividades pendentes;
- provas e entregas realizadas;
- notas liberadas;
- componentes de cada RA;
- score e nível de atenção;
- e-mails preventivos automáticos;
- histórico de eventos exibido na linha do tempo.

### RAs diferentes por matéria

Algumas disciplinas possuem **2 RAs** e outras **3 RAs**. Cada RA pode ter componentes diferentes, por exemplo:

- Prova + Lista prática
- Projeto + Apresentação
- Prova + Atividade reflexiva
- Prova + Seminário
- Produção textual + Atividades

Assim, o sistema consegue explicar **por que a média da RA caiu**. Exemplo: o aluno pode ter média baixa porque foi mal na prova, mesmo tendo bom resultado no projeto.

### Frequência proativa

A frequência usa a carga total prevista da disciplina. O sistema calcula:

`faltas permitidas - faltas já registradas = margem restante`

Faixas do protótipo:

- acima de 5 faltas restantes: normal;
- 5 a 3 faltas restantes: lembrete;
- 2 a 1 faltas restantes: atenção;
- sem margem adicional: crítico.

O sistema evita repetir o mesmo aviso sem mudança relevante de faixa. Na faixa de lembrete, a mensagem mostra quantas faltas ainda restam.

### AVA

O projeto acompanha o **último acesso geral do estudante ao AVA** e as pendências por disciplina.

Faixas iniciais:

- 0–3 dias: normal;
- 4–7 dias: observar;
- 8–14 dias: atenção;
- 15+ dias: crítico.

Na simulação, um aluno pode reduzir o uso do AVA e o sistema passa a gerar um alerta antes que o problema apareça apenas na nota final.

### E-mails automáticos

Os e-mails não são longos. Existem mensagens graduais para:

- frequência;
- resultado de RA;
- inatividade no AVA.

O envio SMTP real não está conectado. Na V3, o backend registra o disparo como `auto_sent_simulated`, permitindo demonstrar a automação sem usar credenciais reais.

### IA não supervisionada

O módulo Python usa **K-Means + StandardScaler** para agrupar alunos por padrões semelhantes, considerando:

- frequência média;
- média acadêmica;
- dias sem AVA;
- pendências;
- média em provas;
- média em projetos.

Os nomes dos grupos são interpretações dos centróides, como:

- risco por frequência;
- desengajamento no AVA;
- dificuldade em provas;
- dificuldade em projetos;
- perfil estável.

## História demonstrativa do aluno-foco

A aluna **Ana Ribeiro** possui uma trajetória planejada para facilitar a apresentação:

1. Começa o semestre sem alerta importante.
2. A RA1 de Raciocínio Algorítmico é liberada e o sistema identifica que o desempenho baixo veio principalmente da **Prova**.
3. Em Filosofia, a margem cai para **5 faltas** e surge o primeiro lembrete preventivo.
4. A margem cai para **2 faltas** e o nível sobe para atenção.
5. O tempo sem entrar no AVA aumenta e gera um alerta de engajamento.
6. Após a intervenção simulada, um novo acesso ao AVA é registrado e o sistema recalcula o risco.

Tudo aparece na linha do tempo da tela de simulação.

## Como rodar

Requisitos:

- Node.js 18+
- npm
- Python 3 apenas para a tela de IA

No terminal do VS Code:

```bash
npm install
npm run dev
```

Abra:

```text
http://localhost:3000
```

Para habilitar o clustering:

```bash
pip install -r requirements.txt
```

No Windows, também é possível usar `INICIAR_WINDOWS.bat`.

## Comandos

```bash
npm run dev
npm test
npm run reset-data
```

## Principais endpoints

```text
GET  /api/simulation
POST /api/simulation/advance
POST /api/simulation/next-event
POST /api/simulation/reset

GET  /api/classes
GET  /api/classes/cc1a/dashboard
GET  /api/classes/cc1a/clusters
GET  /api/students/s1/profile
GET  /api/notifications
```

Veja exemplos completos em `api.http`.

## Estrutura

```text
AlertaEvasao_V3/
├── public/
│   ├── css/
│   ├── js/
│   └── index.html
├── src/
│   ├── controllers/
│   ├── repositories/
│   ├── routes/
│   ├── services/
│   │   ├── academic.service.js
│   │   ├── simulation.service.js
│   │   ├── notification.service.js
│   │   └── clustering.service.js
│   └── data/
├── scripts/
├── tests/
├── docs/
├── api.http
├── package.json
└── server.js
```

## Limitações assumidas

- dados acadêmicos são sintéticos;
- calendário não considera todos os feriados e reposições reais;
- professores e horários são fictícios;
- a matriz pode ser atualizada pela instituição;
- SMTP real, autenticação e integração institucional ainda não foram habilitados;
- clusters de IA são exploratórios e não equivalem a diagnóstico de evasão.

## Apresentação da AP1

O PDF utilizado na apresentação está disponível em [`docs/apresentacao/AP1_Alerta_Evasao.pdf`](docs/apresentacao/AP1_Alerta_Evasao.pdf).

## Instalação completa

### Dependências Node.js

```bash
npm install
```

### Dependências Python para o módulo de clustering

```bash
python -m pip install -r requirements.txt
```

Ou diretamente:

```bash
python -m pip install "numpy>=1.26" "scikit-learn>=1.4"
```

Depois, para iniciar o projeto:

```bash
npm run dev
```

Acesse `http://localhost:3000`.


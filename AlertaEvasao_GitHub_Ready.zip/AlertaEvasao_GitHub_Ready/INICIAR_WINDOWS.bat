@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo ========================================
echo      ALERTA EVASAO V3 - INICIAR
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao foi encontrado. Instale o Node.js 18 ou superior.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando dependencias Node pela primeira vez...
  call npm install
)
echo.
echo Iniciando em http://localhost:3000
echo Para a tela de IA: pip install -r requirements.txt
echo.
start "" http://localhost:3000
call npm run dev
pause

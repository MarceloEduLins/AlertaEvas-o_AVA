const test = require('node:test');
const assert = require('node:assert/strict');
const {
  calculateAssessment,
  calculateAttendance,
  calculateAva
} = require('../src/services/academic.service');
const { buildAttendanceNotification } = require('../src/services/notification.service');

test('calcula RA1 ponderada e identifica componente mais fraco', () => {
  const result = calculateAssessment({
    components: [
      { type: 'Prova', weight: 0.4, grade: 8 },
      { type: 'Projeto', weight: 0.4, grade: 4 },
      { type: 'Atividades', weight: 0.2, grade: 7 }
    ]
  });
  assert.equal(result.grade, 6.2);
  assert.equal(result.weakest.type, 'Projeto');
});

test('calcula margem acumulada de faltas pela carga total da disciplina', () => {
  const result = calculateAttendance(
    { classesHeld: 46, absences: 15 },
    { totalClasses: 80 },
    75
  );
  assert.equal(result.allowedAbsences, 20);
  assert.equal(result.remainingAbsences, 5);
  assert.equal(result.alertLevel, 'reminder');
});

test('classifica inatividade no AVA com data de referência explícita', () => {
  const result = calculateAva(
    { lastAvaAccess: '2026-09-20', pendingActivities: 3 },
    new Date('2026-10-02T12:00:00')
  );
  assert.equal(result.inactiveDays, 12);
  assert.equal(result.alertLevel, 'attention');
});

test('gera e-mail curto quando restam 5 faltas', () => {
  const message = buildAttendanceNotification(
    { name: 'João Silva' },
    {
      subject: { name: 'Banco de Dados' },
      attendance: { alertLevel: 'reminder', remainingAbsences: 5, currentAttendance: 67.4 }
    }
  );
  assert.equal(message.level, 'reminder');
  assert.match(message.body, /5 faltas/);
});

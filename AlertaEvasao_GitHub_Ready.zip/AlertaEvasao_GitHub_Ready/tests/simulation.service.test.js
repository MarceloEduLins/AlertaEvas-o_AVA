const test = require('node:test');
const assert = require('node:assert/strict');
const repository = require('../src/repositories/academic.repository');
const simulation = require('../src/services/simulation.service');
const academic = require('../src/services/academic.service');

test('V3 simula semestre com seis matérias, 5 aulas por dia e ações proativas', () => {
  repository.resetData();
  try {
    const start = simulation.getStatus();
    assert.equal(start.subjects.length, 6);
    assert.equal(start.class.lessonsPerDay, 5);
    assert.ok(start.timetable.every((day) => day.periods.length === 5));
    assert.ok(start.subjects.some((subject) => subject.ras.length === 2));
    assert.ok(start.subjects.some((subject) => subject.ras.length === 3));

    // Avança até depois da liberação da primeira RA de Raciocínio Algorítmico.
    simulation.advance(42);
    const profile = academic.getStudentProfile('s1');
    const alg = profile.subjects.find((item) => item.subject.id === 'alg');
    const ra1 = alg.assessments.find((item) => item.name === 'RA1');
    assert.equal(ra1.weakest.type, 'Prova');
    assert.equal(ra1.weakest.grade, 4.2);
    assert.ok(repository.listNotifications().some((n) => n.studentId === 's1' && n.type === 'grade'));

    // Avança até o marco de 5 faltas restantes.
    simulation.advance(14);
    const later = academic.getStudentProfile('s1');
    const filosofia = later.subjects.find((item) => item.subject.id === 'fil');
    assert.ok(filosofia.attendance.remainingAbsences <= 5);
    assert.ok(repository.listNotifications().some((n) => n.studentId === 's1' && n.type === 'attendance'));
  } finally {
    repository.resetData();
  }
});

# Regras de negócio — V3

## Frequência

A margem é calculada pela carga total da disciplina e pela presença mínima configurada na turma.

- margem > 5: normal
- 3–5: lembrete
- 1–2: atenção
- <= 0: crítico

## Avaliações

Cada disciplina possui 2 ou 3 RAs. Cada RA contém componentes e pesos próprios. A média ponderada é calculada e o componente de menor nota é destacado como explicação do resultado.

## AVA

O último acesso é geral do estudante, enquanto pendências são mantidas por disciplina.

- 0–3 dias: normal
- 4–7: observar
- 8–14: atenção
- 15+: crítico

## Alertas automáticos

Um fingerprint impede repetição do mesmo alerta. Mudanças de faixa podem gerar nova comunicação.

Os e-mails têm três princípios:

1. serem curtos;
2. explicarem o motivo;
3. aumentarem de intensidade apenas quando o risco realmente evolui.

## Score

O score continua sendo um indicador de apoio à decisão, não uma probabilidade real de evasão.

# Roadmap

## V3 — implementado

- simulação temporal do semestre;
- 24 estudantes;
- 6 disciplinas;
- 5 aulas por dia;
- RAs com calendários diferentes;
- análise por componente de RA;
- alertas automáticos graduais;
- AVA geral + pendências por matéria;
- linha do tempo de proatividade;
- K-Means.

## V4

- PostgreSQL;
- importação CSV;
- autenticação;
- tela de configuração de regras por instituição;
- notificações agrupadas/digest;
- gráficos históricos.

## Futuro institucional

- integração com WebAluno/AVA por API autorizada;
- SMTP real;
- validação de critérios com equipe pedagógica;
- avaliação ética e de privacidade/LGPD;
- validação externa dos clusters.

# Arquitetura — V3

```text
Frontend (HTML/CSS/JS)
        ↓
API REST (Node + Express)
        ↓
┌──────────────────────────────────────────────┐
│ Serviços                                     │
│ simulation.service → calendário e eventos    │
│ academic.service   → frequência/RA/AVA/score │
│ notification.service → comunicações          │
│ clustering.service → integração Python       │
└──────────────────────────────────────────────┘
        ↓                         ↓
JSON sintético               Python/K-Means
```

## simulation.service

É a principal novidade da V3. Mantém a data simulada e processa eventos entre duas datas:

- aulas do horário semanal;
- faltas determinísticas por perfil sintético;
- acesso ao AVA;
- pendências;
- aplicação e liberação de RAs;
- linha do tempo;
- comunicações automáticas.

O simulador usa valores determinísticos derivados dos IDs e das datas para que o mesmo reset produza uma demonstração reproduzível.

## Dados

`academic.seed.json` representa o início do semestre.

`academic.json` representa o estado atual da simulação.

`npm run reset-data` restaura o seed.

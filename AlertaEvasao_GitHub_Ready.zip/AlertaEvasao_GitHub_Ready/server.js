const path = require('path');
const express = require('express');
const healthRoutes = require('./src/routes/health.routes');
const academicRoutes = require('./src/routes/academic.routes');
const errorHandler = require('./src/middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/health', healthRoutes);
app.use('/api', academicRoutes);

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use(errorHandler);

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Alerta Evasão rodando em http://localhost:${PORT}`);
  });
}

module.exports = app;
